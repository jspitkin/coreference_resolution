python scorer.py responselist.txt dev/
