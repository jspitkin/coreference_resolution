python scorer.py responselist.txt dev/ -v
