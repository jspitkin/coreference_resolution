python3 install_packages.py
python3 coreference.py all_files.listfile scoring/response_files/
