import nltk
nltk.download('averaged_perceptron_tagger')
